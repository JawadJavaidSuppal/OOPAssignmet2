#include<iostream>
using namespace std;
class String {
private:
	char* arr;
	int currentSize;
	int maxSize;
public:
	String();
	String(const String& str);
	String(const String& str, int pos, int len);
	String(const char* s);
	String(const char* s, int n);
	String(int n, char c);
	int length() const;
	char at(int i);
	//String substr(int pos, int len) const;
	~String();
	friend ostream& operator<< (ostream& os, const String& str) {
		os << *str.arr;
		return os;
	}
};