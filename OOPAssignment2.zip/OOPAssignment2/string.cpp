#include "String.h"

String::String() {
	cout << "Non Parametrized Constructor is called..." << endl;
}
String::String(const String& str) {
	int size = 0;
	int i = 0;
	size = str.length();
	arr = new char[size];

	for (i = 0; i < size; i++) {
		arr[i] = str.arr[i];
	}
	currentSize = i;
}
int String::length() const {
	return currentSize;
}
String::String(const String& str, int pos, int len) {
	currentSize = 0;
	maxSize = pos - len;
	arr = new char[maxSize];
	for (int i = pos, j = 0; i < len; i++, j++) {
		arr[j] = str.arr[i];
		currentSize++;
	}
}
String::String(const char* s) {
	int length = 0;
	while (true) {
		if (s[length] == '\0')
			break;
		else
			length++;
	}
	arr = new char[length + 1];
	for (int i = 0; i < length; i++)
		arr[i] = s[i];
	arr[length] = '\0';
}
String::String(const char* s, int n) {
	while (true) {
		if (s[n] == '\0')
			break;
		else
			n++;
	}
	arr = new char[n + 1];
	for (int i = 0; i < n; i++)
		arr[i] = s[i];
	arr[n] = '\0';
}
String::String(int n, char c) {
	for (int i = 0; i < n; i++) {
		cout << c << endl;
	}
}
char String::at(int i) {
	int len = length();
	if (i < 0 || i > len) {
		return '\0';
	}
	else {
		char c = arr[i];
		return c;
	}
}
String::~String() {
	delete[]arr;
	arr = nullptr;
}

